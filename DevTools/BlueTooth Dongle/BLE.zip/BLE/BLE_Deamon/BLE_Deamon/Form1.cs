﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.IO.Ports;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BLE_Deamon
{
    public partial class Form1 : Form
    {
        String TempRecvBuff = "";
        private byte checkETX = 0xF7;

        System.Data.SqlClient.SqlDataAdapter myreader = new System.Data.SqlClient.SqlDataAdapter();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear(); // Search Port in System
            foreach (string s in SerialPort.GetPortNames())
            {
                comboBox1.Items.Add(s.Substring(0, (s.Length-1))); // or
                //comboBox1.Items.Add(s);
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int bytes = serialPort1.BytesToRead;

            byte[] buffer = new byte[bytes];

            serialPort1.Read(buffer, 0, bytes);

            if (bytes == 0)
                return;

            if (checkETX != buffer[bytes - 1])
            {
                if (TempRecvBuff.Length == 0)
                {
                    TempRecvBuff = ByteArrayToHexString(buffer);
                }
                else if (TempRecvBuff.Length > 0)
                {
                    TempRecvBuff += ByteArrayToHexString(buffer);
                }
            }
            else
            {
                if (TempRecvBuff.Length == 0)
                {
                    DB_Insert(ByteArrayToHexString(buffer));
                    Log(ByteArrayToHexString(buffer));
                }
                else
                {

                    TempRecvBuff += ByteArrayToHexString(buffer);
                    byte[] temp = HexStringToByteArray(TempRecvBuff);

                    if (temp[15] == 0)
                    {
                        DB_Insert(TempRecvBuff);
                        Log(TempRecvBuff);
                    }
                    else
                    {
                        DB_Insert(TempRecvBuff);
                        Log(TempRecvBuff);
                    }
                }
                TempRecvBuff = "";
            }
        }

        private void Log(string msg)
        {
            richTextBox1.Invoke(new EventHandler(delegate
            {
                richTextBox1.SelectedText = string.Empty;
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, FontStyle.Bold);
                richTextBox1.AppendText(msg + "\n");
                richTextBox1.ScrollToCaret();
            }));
        }

        private void DB_Insert(string msg)
        {
            string current_time = System.DateTime.Now.ToString();
            this.sqlInsertCommand1.CommandText = "INSERT INTO log (payload, date) VALUES (@payload, @date)";
            this.sqlInsertCommand1.CommandType = CommandType.Text;
            SqlParameter Pay_Load = new SqlParameter("@payload", SqlDbType.VarChar);
            SqlParameter Cur_Date = new SqlParameter("@date", SqlDbType.VarChar);
            this.sqlInsertCommand1.Connection = this.sqlConnection1;
            this.sqlInsertCommand1.Parameters.Clear();
            Pay_Load.Value = msg;
            Cur_Date.Value = current_time;
            this.sqlInsertCommand1.Parameters.Add(Pay_Load);
            this.sqlInsertCommand1.Parameters.Add(Cur_Date);
            this.sqlConnection1.Open();
            try
            {
                if (this.sqlInsertCommand1.ExecuteNonQuery() < 0)
                {
                    this.sqlConnection1.Close();
                }
                else
                {
                    this.sqlConnection1.Close();
                }
            }
            catch (Exception dbEX)
            {
                this.sqlConnection1.Close();
            }
            finally
            {
                this.sqlConnection1.Close();
            }
        }

        private string ByteArrayToHexString(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 3);
            foreach (byte b in data)
                sb.Append(Convert.ToString(b, 16).PadLeft(2, '0').PadRight(3, ' '));

            return sb.ToString().ToUpper();
        }

        private byte[] HexStringToByteArray(string s)
        {
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
                buffer[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            return buffer;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
                serialPort1.Close();
            else
            {
                serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text.ToString());
                serialPort1.DataBits = int.Parse("8");
                serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), "One");
                serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), "None");
                serialPort1.PortName = comboBox1.Text.ToString();
                serialPort1.Open();
            }
            if (serialPort1.IsOpen)
                button1.Text = "Close Port";
            else
                button1.Text = "Open Port";
        }
    }
}
