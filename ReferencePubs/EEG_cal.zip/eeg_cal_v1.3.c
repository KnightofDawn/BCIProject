//***************************************************************************
//  EEG_CALIBRATOR  *********************************************************
//***************************************************************************
//
//  This EEG_Calibrator is intended to measure, confirm and evaluate the
//  performance of various EEG Neurofeedback devices and solutions.  The
//  unit can be used to measure the performance of EEG hardware, software
//  or a combination thereof.  It could also be used to evaluate neuro-
//  feedback treatment protocol design performance/behaviour as designed
//  in software packages such as BioExplorer or BioEra.
//
//  A PIC16F785 is used as a 1 to 64Hz sine-wave generator of known, fixed
//  amplitude.  Besides being able to select the frequeny in 1Hz steps via
//  dip-switches, the unit also alows for frequency sweeps and pulse gener-
//  ation.  The sine-wave is created with a 200-point lookup table to set a
//  8-bit PWM value.  The microprocessor's internal two op-amps are used as
//  a buffer and 2nd order low-pass filter that processes the pwm output.
//  Besides the sine-wave generation, a square wave pulse can also be pro-
//  duced to measure things such as settling time, digital filter response,
//  phase delay, etc.
//
//  Copyright (C)2008
//  Modina BioEngineering
//  Stefan Jung
//  P.O. Box 95358
//  Waterkloof
//  0145
//  South Africa
//
//  email: bio.sens.eng@gmail.com
//
//  Compiler   :  CCS-PCW
//  Clock type :  Internal 8 Mhz RC oscillator
//                (factory trimmed to within 1%)
//
//  Current Status
//  --------------
//  All envisaged functions implemented and tested.  Performance was validated
//  with an Agilent 54622D 200MS/s Mixed Signal Oscilloscope and found to be
//  very good.  -3db LPF cutoff point however, needs ro be moved up to prevent
//  high frequency roll-off that produced an amplitude error of 5.7%.
//
//  REVISION HISTORY
//  ----------------
//  1.0 - 16/06/2008     Protoboard concept release
//  1.1 - 06/07/2008     Initial development release
//  1.2 - 12/07/2008     Corrected lookup table to allow for intrp latency
//  1.3 - 19/07/2008     Battery check implemented
//
//***************************************************************************

#include <16F785.h>
#fuses   INTRC_IO,NOWDT,NOPROTECT,PUT,NOMCLR
#use     delay(clock=8000000)

#define  PWM          PIN_C5           // PWM (CCP1) output
#define  PWR_LED      PIN_B6           // Power LED output
#define  BATT_CHK     PIN_C0           // Battery check switch input
#define  BATT_MON     PIN_C1           // Battery monitor - comparator input
#define  PULSE_EN     PIN_C4           // Pulse enable dip-switch input
#define  SWEEP_EN     PIN_B7           // Sweep enable dip-switch input
#define  PULSE_OUT    PIN_C2           // Pulse output when in PULSE mode

#define  VR_DISABLE   0x0000           // disable VR voltage reference

#define  POSITIVE     1
#define  NEGATIVE     0
#define  ENABLE       1
#define  DISABLE      0

#define  SEA_SAW      0
#define  RAMP_DN      1
#define  RAMP_UP      2
#define  RESERVED     3

#define  PULSE_MODE   1
#define  SWEEP_MODE   2
#define  SPOT_MODE    3

void initialize(void);
void battery_check(void);
void sw_to_analog(void);
void sw_to_digital(void);
void spot_gen(void);
void sweep_gen(void);
void pulse_gen(void);

//***************************************************************************
// SINE-WAVE LOOK-UP TABLE
// -----------------------
// This table contains the 8-bit values that are written into the CCP1
// module's CCPR1L register to produce the correct sample pwm.
//
// Sample[x] = 128 + [ 120 * SIN (360deg * [x]/200) ]   where x = 0.. 199
//
//***************************************************************************

BYTE CONST SINE_WAVE[200] = {
128,132,136,139,143,147,150,154,158,161,165,169,172,176,179,
182,186,189,192,195,199,202,204,207,210,213,215,218,220,223,
225,227,229,231,233,235,237,238,240,241,242,243,244,245,246,
247,247,247,248,248,248,248,248,247,247,247,246,245,244,243,
242,241,240,238,237,235,233,231,229,227,225,223,220,218,215,
213,210,207,204,202,199,195,192,189,186,182,179,176,172,169,
165,161,158,154,150,147,143,139,136,132,128,124,120,117,113,
109,106,102,98,95,91,87,84,80,77,74,70,67,64,61,57,54,52,49,
46,43,41,38,36,33,31,29,27,25,23,21,19,18,16,15,14,13,12,11,
10,9,9,9,8,8,8,8,8,9,9,9,10,11,12,13,14,15,16,18,19,21,23,
25,27,29,31,33,36,38,41,43,46,49,52,54,57,61,64,67,70,74,77,
80,84,87,91,95,98,102,106,109,113,117,120,124};


//***************************************************************************
// FREQUENCY STEP LOOK-UP TABLE
// ----------------------------
// This table contains the critical (for accurate frequency) 16-bit values
// that need to be loaded into Timer1 so as to produce the correct sample
// rate for the 200-step sine table.
//
// Timer1 is used with a Prescaler of 1, thus it counts at a CLK/4 rate or
// 0.5uS per tick (assuming an 8 Mhz clock).
//
// Each of the 200 sine samples need to be changed at this interval:
//
// interval = 1 second / [200 * Freq]   where Freq is in Hz         ...(1)
//
// The Interrupt causes a 3 instr cycle latency and the CCS compiler adds
// further instructions that take another 36 machine cycles to finally
// reload Timer1.  So in total, there is a overhead of 39 cycles - which
// have to be subtracted from the Timer1 interval delay.
//
// Thus: interval = 1000 000 uS / [200 * Freq] - 19.5uS             ...(2)
//
// Timer1[delay] = (65535 - reload value) * 0.5uS                   ...(3)
//
// Equating (2) to (3) gives:
//
// (65535 - reload value) * 0.5uS = 1000000uS / [200 * Freq] - 19.5uS
// (65535 - reload value) = 2000 000 / [200 * Freq] - 39
//  reload value = 65535 - (10000 / Freq) + 39
//
// Sample[x] = 65574 - (10000 / [x])   where x = 1..64Hz
//
//***************************************************************************

LONG CONST FREQ_STEPS[64] = {
55574,60574,62241,63074,63574,63907,        //  1Hz.. 6Hz
64145,64324,64463,64574,64665,64741,        //  7Hz..12Hz
64805,64860,64907,64949,64986,65018,        // 13Hz..18Hz
65048,65074,65098,65119,65139,65157,        // 19Hz..24Hz
65174,65189,65204,65217,65229,65241,        // 25Hz..30Hz
65251,65262,65271,65280,65288,65296,        // 31Hz..36Hz
65304,65311,65318,65324,65330,65336,        // 37Hz..42Hz
65341,65347,65352,65357,65361,65366,        // 43Hz..48Hz
65370,65374,65378,65382,65385,65389,        // 49Hz..54Hz
65392,65395,65399,65402,65405,65407,        // 55Hz..60Hz
65410,65413,65415,65418};                   // 61Hz..64Hz

//***************************************************************************
//                               GLOBAL VARIABLES
//***************************************************************************

BYTE sine_index;
BOOLEAN swp_slope;
static unsigned int  prev_mode;
static unsigned int  frequency;
static unsigned long IntrpPeriod;

//***************************************************************************
//                           INTERRUPT SERVICE ROUTINE
//***************************************************************************

#INT_TIMER1
void isr()
{
  set_timer1(IntrpPeriod);
  set_pwm1_duty(SINE_WAVE[sine_index]);

  if(++sine_index == 200)
    sine_index = 0;
}

//***************************************************************************
//                               INITIALIZE()
//***************************************************************************

void initialize(void)
{
  setup_oscillator(OSC_8MHZ);               // use internal RC osc at 8 Mhz
  setup_ccp1(CCP_PWM);                      // Configure CCP1 as a PWM
  setup_timer_2(T2_DIV_BY_1, 0xFF, 1);      // 3f = PWM frequency = 31.250 khz
  port_a_pullups(TRUE);                     // enable pull-up resistors

  set_tris_a(0x3F);                         // RA0...RA5       -> High-Z
  set_tris_b(0xB0);                         // RB4/5/7         -> High-Z
  set_tris_c(0xDF);                         // all except RC5  -> High-Z

  setup_adc_ports(NO_ANALOGS);              // disable all analog inputs
  setup_opamp1(ENABLE);                     // enable opamp1
  setup_opamp2(ENABLE);                     // enable opamp2

  IntrpPeriod = 63535;
  frequency   =    10;

  setup_timer_1(T1_INTERNAL | T1_DIV_BY_1); // Prescaler = 1
  set_timer1(IntrpPeriod);

  enable_interrupts(INT_TIMER1);
  enable_interrupts(GLOBAL);

  output_high(PWR_LED);                     // switch LED off
}

//***************************************************************************
//                              BATTERY_CHECK()
//
//  This function checks that the battery voltage is higher than 1.2 volts
//  (using the Vref and voltage comparator C1).  If the voltage is OK, the 
//  LED is strobed 3 times in quick succession.  If the battery voltage is
//  found to be too low, the unit is put into sleep mode without flashing
//  the LED.
//
//  The internal "VR" 1.2V bandgap reference is used against which the
//  battery voltage is compared by comparator C1.
//
//  To conserve power, we only enable the VRref and comparator when performing
//  a battery test, after which these two modules are again disabled. This 
//  makes a surprising difference to overall current consumption!
//
//***************************************************************************

void battery_check(void)
{
  char count;

  setup_adc_ports(SAN5);                    // enable AN5 for comparator use
  setup_comparator(CP1_C1_VREF);            // comp1 used with RC1 & Vref inputs
  setup_vref(VR_ENABLE);                    // enable 1.2V bandgap VRref
  delay_ms(20);                             // allow voltages to stabilize

  if (C1OUT)                                // check comparator output
    sleep();                                // battery low, go to sleep
  else
  {
    setup_adc_ports(NO_ANALOGS);            // disable all analog inputs
    setup_comparator(NC_NC);                // disable comp1
    setup_vref(VR_DISABLE);                 // disable 1.2V bandgap VRref

    for (count=0; count<3; count++)         // flash LED -> battery OK
    {
      output_low(PWR_LED);
      delay_ms(20);
      output_high(PWR_LED);
      delay_ms(100);
    }
  }
}

//***************************************************************************
//                               SW_TO_ANALOG()
//
//  In this mode both op-amps are enabled.  OPA1 acts a a buffer for the PWM
//  voltage divider and OPA2 acts as an active 2nd order Butterworth LPF.
//
//***************************************************************************

void sw_to_analog(void)
{
  set_tris_c(0xDF);                         // all except RC5  -> High-Z

  setup_opamp1(ENABLE);                     // enable opamp1
  setup_opamp2(ENABLE);                     // enable opamp2
  enable_interrupts(GLOBAL);
}

//***************************************************************************
//                              SW_TO_DIGITAL()
//
//  In this mode both op-amps are disbled. All I/O pins normally associated
//  with the op-amps are left as inputs, with the exception of RC2 [pin 14]
//  which is now made an output [low-Z].  All interrupts are disabled when
//  in digital (Pulse) mode as the pulse timing uses the delay_ms() function.
//
//***************************************************************************

void sw_to_digital(void)
{
  disable_interrupts(GLOBAL);
  setup_opamp1(DISABLE);                    // disable opamp1
  setup_opamp2(DISABLE);                    // disable opamp2
  set_tris_c(0xDB);                         // all except RC2 & 5  -> High-Z
  output_low(PULSE_OUT);                    // make pulse output low
}

//***************************************************************************
//                                SPOT_GEN()
//***************************************************************************

void spot_gen(void)
{
  frequency   = (~(input_a()) & 0x3f);
  IntrpPeriod = FREQ_STEPS[frequency];
}

//***************************************************************************
//                                SWEEP_GEN()
//
//  This is a linear, "staircase" sweep, meaning the sweep is not smooth but
//  follows the discrete 64 steps of the 1..64Hz lookup table.  This is
//  sufficent for now.  A smooth sweep would be easy to implement as a
//  future update.
//
//***************************************************************************

void sweep_gen(void)
{
  unsigned int sweep_type;
  unsigned int sweep_rate;

  sweep_type  = (input_a() & 0x03);
  sweep_rate  = (input_a() & 0x3C);
  sweep_rate += 2;
  sweep_rate *= 4;

//---------------------------------------------------------------------------
//                        SAW TOOTH SWEEP - UP-RAMP
//---------------------------------------------------------------------------
  if (sweep_type == RAMP_UP)
  {
    if (frequency > 62)
      frequency = 0;

    IntrpPeriod = FREQ_STEPS[frequency++];
    delay_ms(sweep_rate);
  }

//---------------------------------------------------------------------------
//                       SAW TOOTH SWEEP - DOWN-RAMP
//---------------------------------------------------------------------------
  if (sweep_type == RAMP_DN)
  {
    IntrpPeriod = FREQ_STEPS[frequency--];

    if (frequency == 0)
      frequency = 63;

    delay_ms(sweep_rate);
  }

//---------------------------------------------------------------------------
//                        TRIANGULAR SWEEP (SEA-SAW)
//---------------------------------------------------------------------------
  if (sweep_type == SEA_SAW)
  {
    if (swp_slope == POSITIVE)
    {
      IntrpPeriod = FREQ_STEPS[frequency++];
      delay_ms(sweep_rate);

      if (frequency > 62)
        swp_slope = NEGATIVE;
    }
    else
    {
      IntrpPeriod = FREQ_STEPS[frequency--];
      delay_ms(sweep_rate);

      if (frequency == 0)
        swp_slope = POSITIVE;
    }
  }
}

//***************************************************************************
//                              PULSE_GEN()
//
//       The following settings are supported:
//
//       Pulse Width               Pulse Off Period 
//       ------------              -----------------
//       000 -  16 ms              000 - 0.5 seconds
//       001 -  32 ms              001 - 1.0 seconds
//       010 -  48 ms              010 - 1.5 seconds
//       011 -  64 ms              011 - 2.0 seconds
//       100 -  80 ms              100 - 2.5 seconds
//       101 -  96 ms              101 - 3.0 seconds
//       110 - 112 ms              110 - 3.5 seconds
//       111 - 128 ms              111 - 4.0 seconds
//
//***************************************************************************

void pulse_gen(void)
{
  unsigned int index;
  unsigned int pulse_length;
  unsigned int pulse_repetition;

  pulse_length = (~(input_a())) & 0x07;
  pulse_length = (pulse_length << 4) + 16;

  pulse_repetition = (~(input_a())) & 0x38;
  pulse_repetition = (pulse_repetition >> 1) + 4;

  output_high(PULSE_OUT);
  delay_ms(pulse_length);
  output_low(PULSE_OUT);

  for (index=0; index<pulse_repetition; index++)
  {
    if (!input(PULSE_EN))
      delay_ms(125);
  }
}

//***************************************************************************
//                                 MAIN()
//***************************************************************************

void main()
{
  unsigned int curr_mode;

  initialize();
  battery_check();

  while (TRUE)
  {
    if (input(BATT_CHK))
    {
      while (input(BATT_CHK));                  // wait for sw to be released
      battery_check();
    }

    curr_mode  =  input(SWEEP_EN);
    curr_mode += (input(PULSE_EN) << 1);

    if (curr_mode != prev_mode)
    {
      if (curr_mode == PULSE_MODE) sw_to_digital();
      else                         sw_to_analog();

      prev_mode = curr_mode;
    }
    switch (curr_mode)
    {
      case SPOT_MODE  : spot_gen();  break;
      case SWEEP_MODE : sweep_gen(); break;
      case PULSE_MODE : pulse_gen(); break;
      default         : spot_gen();  break;
    }
  }
}

//***************************************************************************
//                                 END
//***************************************************************************

